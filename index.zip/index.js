/**
 * =============================================================================
 * BACKEND: index.js (Versión Maestra 3.7 - INTEGRIDAD Y SEGURIDAD VISUAL)
 * =============================================================================
 * Servidor central de Brinco Creativo. 
 * DIRECTIVA: Mantenimiento de densidad lógica >430 líneas.
 * 
 * Historial de Versiones:
 * v1.0 - Estructura básica de Express.
 * v3.0 - Integración de módulos de Clientes y Proveedores.
 * v3.5 - Sistema de Caja y Pagos.
 * v3.6 - Gestión de Permisos Granulares y Avatares.
 * v3.7 - Implementación de Endpoint de Perfil Público para Login Visual.
 * 
 * Este archivo contiene toda la lógica de negocio para la gestión de un taller
 * de personalización, incluyendo inventarios, órdenes de trabajo, finanzas
 * y administración de usuarios con permisos específicos por módulo.
 */

const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const { fileTypeFromFile } = require('file-type');
const multerLib = require('multer');
const path = require('path');
const fs = require('fs');
require('dotenv').config();
const rateLimit = require('express-rate-limit');
const app = express();
const corsOrigins = [
  'http://localhost:5173', // Para tu computadora
  'https://brinco-frontend.onrender.com' // Para la nube 
];

app.use(cors({
  origin: corsOrigins,
  credentials: true
}));
const sharp = require('sharp');
const puppeteer = require('puppeteer');
app.use(express.json());
const { OpenAI } = require("openai");
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'brinco_creativo_secret_2026';

const { CloudinaryStorage } = require('multer-storage-cloudinary');

// Configurar Cloudinary
const cloudinary = require('cloudinary').v2;

// Configurar Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

// Multer en memoria (no toca el disco duro, perfecto para Render)
const uploadMem = multerLib({ storage: multerLib.memoryStorage() });

// =============================================================================
// CONFIGURACIÓN DE RECURSOS Y ARCHIVOS
// =============================================================================

// Acceso estático para imágenes subidas (evidencias y avatares)
app.use('/uploads', express.static('uploads'));

// Verificación y creación de directorio de almacenamiento
if (!fs.existsSync('./uploads')) {
    fs.mkdirSync('./uploads');
    console.log('📁 Directorio /uploads inicializado correctamente.');
}

// Configuración de Multer para gestión de archivos multimedia
const storage = multerLib.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => {
        const prefix = file.fieldname === 'avatar' ? 'avatar' : 'evidencia';
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, `${prefix}-${uniqueSuffix}${path.extname(file.originalname)}`);
    }
});

const upload = multerLib({ 
    storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // Límite de 10MB para fotos de taller
    fileFilter: (req, file, cb) => {
        const filetypes = /jpeg|jpg|png|gif|mp4/;
        const mimetype = filetypes.test(file.mimetype);
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        if (mimetype && extname) return cb(null, true);
        cb(new Error("Error: Tipo de archivo no soportado."));
    }
});

const storagePresupuestos = multerLib.diskStorage({
    destination: (req, file, cb) => {
        const dir = './uploads/presupuestos';
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        cb(null, `presup-${Date.now()}-${file.originalname.replace(/\s/g, '')}`);
    }
});
const uploadPresupuesto = multerLib({ storage: storagePresupuestos, limits: { fileSize: 5 * 1024 * 1024 } });

// Hacer estática la carpeta
app.use('/uploads/presupuestos', express.static('uploads/presupuestos'));

// =============================================================================
// CONEXIÓN A BASE DE DATOS (MYSQL POOL)
// =============================================================================

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '',
    database: process.env.DB_NAME || 'brinco_creativo',
    port: process.env.DB_PORT || 3306,
    waitForConnections: true,
    connectionLimit: 20,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000,
    ssl: { rejectUnauthorized: false }
});

const db = pool.promise();

// Verificación inicial de salud de la base de datos
pool.getConnection((err, connection) => {
    if (err) {
        console.error('❌ ERROR DE CONEXIÓN MYSQL:', err.message);
        console.error('Verifique que el servicio MySQL esté activo y las credenciales sean correctas.');
        return;
    }
    console.log('✅ ESTADO: Servidor v3.7 en línea.');
    console.log('✅ DB: Conectado a la base de datos Brinco Creativo.');
    connection.release();
});


// =============================================================================
// MIDDLEWARE DE AUTENTICACIÓN (JWT)
// =============================================================================
const autenticar = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Token de acceso requerido' });
    }
    const token = authHeader.split(' ')[1];
    try {
        const payload = jwt.verify(token, JWT_SECRET);
        req.usuario = payload; // { id, usuario, rol }
        next();
    } catch (err) {
        return res.status(401).json({ error: 'Token inválido o expirado' });
    }
};

// =============================================================================
// MIDDLEWARE DE AUTORIZACIÓN (POR PERMISO)
// =============================================================================

const autorizar = (permisoRequerido) => {
    return async (req, res, next) => {
        try {
            const [rows] = await db.query(
                `SELECT *
                 FROM usuarios_permisos p WHERE p.usuario_id = ?`,
                [req.usuario.id]
            );
            if (rows.length === 0 || rows[0][permisoRequerido] !== 1) {
                return res.status(403).json({ error: 'No tenés permisos para esta acción' });
            }
            req.permisos = rows[0];
            next();
        } catch (err) {
            res.status(500).json({ error: 'Error al verificar permisos' });
        }
    };
};

// ==========================================================
// MANTENIMIENTO DE MATERIALES POR ORDEN
// ==========================================================
// Obtener materiales de una orden específica (LEYENDO DESDE LA COTIZACIÓN)
app.get('/api/ordenes/:id/materiales', autenticar, autorizar('p_ordenes'), async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT pdm.id, pdm.producto_id, p.nombre as producto_nombre, pdm.cantidad, 
                   pdm.costo_unitario as costo_unitario, pdm.precio_venta as precio_venta
            FROM brinco_creativo.presupuestos_detalles_materiales pdm
            JOIN brinco_creativo.ordenes o ON o.presupuesto_id = pdm.presupuesto_id
            JOIN brinco_creativo.productos p ON pdm.producto_id = p.id
            WHERE o.id = ?
        `, [req.params.id]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Actualizar los materiales de una orden (ACTUALIZANDO LA COTIZACIÓN VINCULADA)
app.put('/api/ordenes/:id/materiales', autenticar, autorizar('p_ordenes'), async (req, res) => {
    const { id } = req.params;
    const { materiales } = req.body;
    const conn = await pool.promise().getConnection();
    
    try {
        await conn.beginTransaction();
        
        // 1. Buscamos el presupuesto_id asociado a esta orden
        const [ordenData] = await conn.query("SELECT presupuesto_id FROM brinco_creativo.ordenes WHERE id = ?", [id]);
        if (ordenData.length === 0 || !ordenData[0].presupuesto_id) {
            throw new Error("La orden no tiene una cotización vinculada para editar materiales.");
        }
        const presupuestoId = ordenData[0].presupuesto_id;

        // 2. Borramos los materiales anteriores de la cotización
        await conn.query("DELETE FROM brinco_creativo.presupuestos_detalles_materiales WHERE presupuesto_id = ?", [presupuestoId]);
        
        // 3. Insertamos los nuevos materiales en la cotización
        for (const m of materiales) {
            await conn.query(
                "INSERT INTO brinco_creativo.presupuestos_detalles_materiales (presupuesto_id, producto_id, cantidad, costo_unitario, precio_venta) VALUES (?, ?, ?, ?, ?)", 
                [presupuestoId, m.producto_id, m.cantidad, m.costo_unitario, m.precio_venta]
            );
        }

        await conn.commit();
        res.json({ message: 'Materiales actualizados correctamente en la cotización vinculada' });
    } catch (err) {
        await conn.rollback();
        res.status(500).json({ error: 'Error al actualizar materiales: ' + err.message });
    } finally {
        conn.release();
    }
});

app.get('/api/test-ruta', (req, res) => res.json({ ok: true }));

// Endpoint para obtener datos del usuario autenticado
app.get('/api/me', autenticar, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT u.id, u.nombre, u.usuario, u.rol, u.activo, u.avatar_url,
                    p.p_dashboard, p.p_clientes, p.p_ordenes, p.p_nueva_orden, p.p_inventario, 
                    p.p_proveedores, p.p_entrada_mercancia, p.p_caja, p.p_cat_clientes, p.p_cat_productos, p.p_usuarios
             FROM usuarios u
             LEFT JOIN usuarios_permisos p ON u.id = p.usuario_id
             WHERE u.id = ?`,
            [req.usuario.id]
        );
        if (rows.length === 0) return res.status(404).json({ error: 'Usuario no encontrado' });
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// =============================================================================
// ENDPOINTS DE USUARIOS Y SEGURIDAD
// =============================================================================

/**
 * LOGIN: Autenticación de usuario
 * Devuelve datos de perfil y tabla de permisos granulares.
 */
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 5, // 5 intentos
  message: { error: 'Demasiados intentos. Intenta de nuevo en 15 minutos.' },
  standardHeaders: true,
  legacyHeaders: false
});

app.post('/api/login', loginLimiter, async (req, res) => {
    const { usuario, password } = req.body;
    try {
        const sql = `
            SELECT u.id, u.nombre, u.usuario, u.rol, u.activo, u.avatar_url, u.password_hash,
            p.p_dashboard, p.p_clientes, p.p_ordenes, p.p_nueva_orden, p.p_inventario, 
            p.p_proveedores, p.p_entrada_mercancia, p.p_caja, p.p_cat_clientes, p.p_cat_productos, p.p_usuarios
            FROM usuarios u
            LEFT JOIN usuarios_permisos p ON u.id = p.usuario_id
            WHERE u.usuario = ? AND u.activo = 1`;
        
        const [users] = await db.query(sql, [usuario]);
        
        if (users.length === 0) {
            return res.status(401).json({ error: 'Credenciales inválidas o cuenta bloqueada' });
        }

        const user = users[0];
        
        // Comparar contraseña en texto plano (soporte durante la transición)
        let passwordValida = false;
        if (user.password_hash.startsWith('$2b$')) {
            // Ya está hasheada con bcrypt
            passwordValida = await bcrypt.compare(password, user.password_hash);
        } else {
            // Contraseña antigua en texto plano → comparación directa
            passwordValida = (password === user.password_hash);
            // Si es válida, migrar a bcrypt automáticamente
            if (passwordValida) {
                const nuevoHash = await bcrypt.hash(password, 10);
                await db.query("UPDATE usuarios SET password_hash = ? WHERE id = ?", [nuevoHash, user.id]);
                console.log(`🔐 Contraseña migrada a bcrypt para usuario ${usuario}`);
            }
        }

        if (!passwordValida) {
            return res.status(401).json({ error: 'Credenciales inválidas o cuenta bloqueada' });
        }

        // Generar token JWT con datos básicos (sin permisos para no exponerlos)
        const tokenPayload = { id: user.id, usuario: user.usuario, rol: user.rol };
        const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '8h' });

        // Devolver token y datos de usuario (sin el hash)
        delete user.password_hash;
        res.json({ 
            success: true, 
            token,
            user: {
                id: user.id,
                nombre: user.nombre,
                usuario: user.usuario,
                rol: user.rol,
                activo: user.activo,
                avatar_url: user.avatar_url,
                permisos: {
                    p_dashboard: user.p_dashboard,
                    p_clientes: user.p_clientes,
                    p_ordenes: user.p_ordenes,
                    p_nueva_orden: user.p_nueva_orden,
                    p_inventario: user.p_inventario,
                    p_proveedores: user.p_proveedores,
                    p_entrada_mercancia: user.p_entrada_mercancia,
                    p_caja: user.p_caja,
                    p_cat_clientes: user.p_cat_clientes,
                    p_cat_productos: user.p_cat_productos,
                    p_usuarios: user.p_usuarios,
                }
            }
        });
    } catch (err) {
        res.status(500).json({ error: 'Fallo interno en login: ' + err.message });
    }
});

/**
 * PERFIL PÚBLICO: Recuperar avatar para el login visual (v3.7)
 * Permite buscar el avatar y nombre por username antes de autenticar.
 */
app.get('/api/usuarios/perfil/:username', async (req, res) => {
    const { username } = req.params;
    try {
        const sql = "SELECT nombre, avatar_url FROM usuarios WHERE usuario = ? AND activo = 1 LIMIT 1";
        const [results] = await db.query(sql, [username]);
        
        if (results.length > 0) {
            res.json(results[0]);
        } else {
            res.status(404).json({ error: 'Usuario no encontrado' });
        }
    } catch (err) {
        res.status(500).json({ error: 'Error al consultar perfil: ' + err.message });
    }
});

app.get('/api/usuarios', autenticar, autorizar('p_usuarios'), async (req, res) => {
    try {
        const sql = `
            SELECT u.id, u.nombre, u.usuario, u.rol, u.activo, u.avatar_url,
            p.p_dashboard, p.p_clientes, p.p_ordenes, p.p_nueva_orden, p.p_inventario, 
            p.p_proveedores, p.p_entrada_mercancia, p.p_caja, p.p_cat_clientes, p.p_cat_productos, p.p_usuarios
            FROM usuarios u
            LEFT JOIN usuarios_permisos p ON u.id = p.usuario_id
            ORDER BY u.nombre ASC`;
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/usuarios', autenticar, autorizar('p_usuarios'), async (req, res) => {
    const { nombre, usuario, password, rol, permisos } = req.body;
    const conn = await pool.promise().getConnection();
    try {
        await conn.beginTransaction();
        const hashedPassword = await bcrypt.hash(password, 10);
        const [resU] = await conn.query("INSERT INTO usuarios (nombre, usuario, password_hash, rol, activo) VALUES (?, ?, ?, ?, 1)", [nombre, usuario, hashedPassword, rol]);
        const userId = resU.insertId;
        const p = permisos || {};
        const sqlP = `INSERT INTO usuarios_permisos (usuario_id, p_dashboard, p_clientes, p_ordenes, p_nueva_orden, p_inventario, p_proveedores, p_entrada_mercancia, p_caja, p_operar_caja, p_apertura_caja, p_cierre_caja, p_historial_caja, p_cat_clientes, p_cat_productos, p_usuarios) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        await conn.query(sqlP, [
            userId, 
            p.p_dashboard ?? 1, p.p_clientes ?? 1, p.p_ordenes ?? 1, p.p_nueva_orden ?? 1, 
            p.p_inventario ?? 1, p.p_proveedores ?? 1, p.p_entrada_mercancia ?? 1, 
            p.p_caja ?? 1, p.p_operar_caja ?? 1, p.p_apertura_caja ?? 1, p.p_cierre_caja ?? 1, p.historial_caja ?? 1,
            p.p_cat_clientes ?? 1, p.p_cat_productos ?? 1, p.p_usuarios ?? 0
        ]);
        await conn.commit();
        res.json({ id: userId, message: 'Usuario creado con éxito' });
    } catch (err) {
        await conn.rollback();
        res.status(500).json({ error: 'Fallo al crear usuario: ' + err.message });
    } finally {
        conn.release();
    }
});

app.put('/api/usuarios/:id', autenticar, autorizar('p_usuarios'), async (req, res) => {
    const { id } = req.params;
    const { nombre, rol, activo, password, permisos } = req.body;
    const conn = await pool.promise().getConnection();
    try {
        await conn.beginTransaction();
        if (password) {
            const hashedPassword = await bcrypt.hash(password, 10);
            await conn.query("UPDATE usuarios SET nombre=?, rol=?, activo=?, password_hash=? WHERE id=?", [nombre, rol, activo, hashedPassword, id]);
        } else {
            await conn.query("UPDATE usuarios SET nombre=?, rol=?, activo=? WHERE id=?", [nombre, rol, activo, id]);
        }
        if (permisos) {
            const p = permisos;
            const sqlP = `UPDATE usuarios_permisos SET 
                p_dashboard=?, p_clientes=?, p_ordenes=?, p_nueva_orden=?, p_inventario=?, p_proveedores=?, p_entrada_mercancia=?, 
                p_caja=?, p_operar_caja=?, p_apertura_caja=?, p_cierre_caja=?, p_historial_caja=?,
                p_cat_clientes=?, p_cat_productos=?, p_usuarios=? 
                WHERE usuario_id=?`;
            await conn.query(sqlP, [
                p.p_dashboard, p.p_clientes, p.p_ordenes, p.p_nueva_orden, p.p_inventario, p.p_proveedores, p.p_entrada_mercancia, 
                p.p_caja, p.p_operar_caja, p.p_apertura_caja, p.p_cierre_caja, p.historial_caja,
                p.p_cat_clientes, p.p_cat_productos, p.p_usuarios, id
            ]);
        }
        await conn.commit();
        res.json({ message: 'Perfil y permisos actualizados' });
    } catch (err) {
        await conn.rollback();
        res.status(500).json({ error: err.message });
    } finally {
        conn.release();
    }
});

// ─────────────────────────────────────────────────────────────────────────────
// Sube una o varias fotos nuevas a una orden
// ─────────────────────────────────────────────────────────────────────────────
app.post('/api/ordenes/:id/evidencias', autenticar, autorizar('p_ordenes'), uploadMem.array('fotos', 10), async (req, res) => {
    const { id } = req.params;
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ error: 'No se recibieron archivos' });
        }

        const nuevasFotos = [];
        for (const file of req.files) {
            const b64 = Buffer.from(file.buffer).toString("base64");
            const dataURI = "data:" + file.mimetype + ";base64," + b64;
            
            // Detectar si es imagen o video
            const resource_type = file.mimetype.startsWith('video/') ? 'video' : 'image';
            
            const uploadResponse = await cloudinary.uploader.upload(dataURI, {
                folder: 'brinco-erp/evidencias',
                resource_type: resource_type
            });
            
            const [result] = await db.query(
                'INSERT INTO orden_evidencias (orden_id, url_archivo) VALUES (?, ?)',
                [id, uploadResponse.secure_url]
            );
            
            nuevasFotos.push({
                id: result.insertId,
                url_archivo: uploadResponse.secure_url,
                tags: []
            });
        }

        res.json({ message: 'Fotos subidas', fotos: nuevasFotos });
    } catch (err) {
        res.status(500).json({ error: 'Error al subir fotos: ' + err.message });
    }
});

// =============================================================================
// ENDPOINTS DE DASHBOARD Y ANALÍTICA
// =============================================================================

app.get('/api/dashboard/stats', autenticar, autorizar('p_dashboard'), async (req, res) => {
    try {
        const sql = `
            SELECT 
                (SELECT COUNT(*) FROM ordenes WHERE estado NOT IN ('Entregado', 'Cancelado', 'Rechazado')) as ordenes_activas,
                (SELECT COUNT(*) FROM productos WHERE stock_actual <= stock_minimo AND activo = TRUE) as stock_bajo,
                (SELECT COALESCE(SUM(monto), 0) FROM pagos WHERE tipo_movimiento = 'Ingreso' AND DATE(fecha_pago) = CURDATE()) as ventas_hoy,
                (SELECT COALESCE(SUM(monto), 0) FROM pagos WHERE tipo_movimiento = 'Egreso' AND DATE(fecha_pago) = CURDATE()) as egresos_hoy
        `;
        const [results] = await db.query(sql);
        
        // Calculamos la utilidad restando egresos a los ingresos
        const stats = results[0];
        stats.utilidad_hoy = Number(stats.ventas_hoy) - Number(stats.egresos_hoy);
        
        res.json(stats);
    } catch (err) {
        res.status(500).json({ error: 'Error al recuperar estadísticas: ' + err.message });
    }
});
app.get('/api/dashboard/ordenes-detalle', autenticar, autorizar('p_ordenes'), async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT 
                o.id,
                COUNT(DISTINCT oe.id)  AS total_evidencias,
                COUNT(DISTINCT et.tag_id) AS total_tags
            FROM ordenes o
            LEFT JOIN orden_evidencias oe ON oe.orden_id = o.id
            LEFT JOIN evidencia_tags et   ON et.evidencia_id = oe.id
            GROUP BY o.id
        `);
        // Devolver como mapa { orden_id: { total_evidencias, total_tags } }
        const mapa = {};
        rows.forEach(r => { mapa[r.id] = { total_evidencias: r.total_evidencias, total_tags: r.total_tags }; });
        res.json(mapa);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});




app.get('/api/dashboard/ventas-semana', autenticar, autorizar('p_caja'), async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT 
                DATE(fecha_pago) as fecha,
                DAYNAME(fecha_pago) as dia_nombre,
                COALESCE(SUM(CASE WHEN tipo_movimiento = 'Ingreso' THEN monto ELSE 0 END), 0) as ingresos,
                COALESCE(SUM(CASE WHEN tipo_movimiento = 'Egreso'  THEN monto ELSE 0 END), 0) as egresos
            FROM pagos
            WHERE fecha_pago >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
            GROUP BY DATE(fecha_pago), DAYNAME(fecha_pago)
            ORDER BY fecha ASC
        `);

        // Rellenar los 7 días aunque no tengan movimientos
        const dias = [];
        for (let i = 6; i >= 0; i--) {
            const d = new Date();
            d.setDate(d.getDate() - i);
            const fecha = d.toISOString().split('T')[0];
            const encontrado = rows.find(r => r.fecha.toISOString().split('T')[0] === fecha);
            dias.push({
                fecha,
                dia: ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'][d.getDay()],
                ingresos: encontrado ? Number(encontrado.ingresos) : 0,
                egresos:  encontrado ? Number(encontrado.egresos)  : 0,
            });
        }
        res.json(dias);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/dashboard/stock-bajo',autenticar, autorizar('p_inventario'), async (req, res) => {
    try {
        const sql = "SELECT id, nombre, stock_actual, stock_minimo FROM productos WHERE stock_actual <= stock_minimo AND activo = TRUE ORDER BY stock_actual ASC";
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// =============================================================================
// GESTIÓN DE CLIENTES Y CATEGORÍAS
// =============================================================================

app.get('/api/clientes', autenticar, autorizar('p_clientes'), async (req, res) => {
    try {
        const sql = "SELECT c.*, cat.nombre as categoria_nombre, cat.color_clase FROM clientes c LEFT JOIN clientes_categorias cat ON c.categoria_id = cat.id ORDER BY c.nombre_completo ASC";
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/clientes', autenticar, autorizar('p_clientes'), async (req, res) => {
    const { nombre_completo, telefono, email, direccion_envio, nit, categoria_id } = req.body;
    try {
        const [result] = await db.query("INSERT INTO clientes (nombre_completo, telefono, email, direccion_envio, nit, categoria_id) VALUES (?,?,?,?,?,?)", [nombre_completo, telefono, email, direccion_envio, nit, categoria_id]);
        res.json({ id: result.insertId });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/clientes/categorias', autenticar, autorizar('p_cat_clientes'), async (req, res) => {
    try {
        const sql = `SELECT cc.*, (SELECT COUNT(*) FROM clientes WHERE categoria_id = cc.id) as total_clientes FROM clientes_categorias cc ORDER BY cc.nombre ASC`;
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Actualizar datos de facturación o contacto del cliente
app.put('/api/clientes/:id', autenticar, autorizar('p_clientes'), async (req, res) => {
    const { id } = req.params;
    const { nombre_completo, telefono, email, direccion_envio, nit, categoria_id } = req.body;
    try {
        const sql = "UPDATE clientes SET nombre_completo=?, telefono=?, email=?, direccion_envio=?, nit=?, categoria_id=? WHERE id=?";
        await db.query(sql, [nombre_completo, telefono, email, direccion_envio, nit, categoria_id, id]);
        res.json({ message: 'Perfil del cliente actualizado' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Obtener el historial comercial de un cliente específico
app.get('/api/clientes/:id/historial',autenticar, autorizar('p_clientes'), async (req, res) => {
    try {
        const { id } = req.params;
        const sql = "SELECT id, fecha_orden, estado, total_quetzales, notas_personalizacion FROM ordenes WHERE cliente_id = ? ORDER BY fecha_orden DESC";
        const [results] = await db.query(sql, [id]);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// =============================================================================
// GESTIÓN DE INVENTARIO Y CATEGORÍAS PRODUCTOS
// =============================================================================

app.get('/api/inventario', autenticar, autorizar('p_inventario'), async (req, res) => {
    try {
        const sql = "SELECT p.*, c.nombre as categoria_nombre FROM brinco_creativo.productos p LEFT JOIN brinco_creativo.categorias c ON p.categoria_id = c.id ORDER BY p.nombre ASC";
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/inventario-proveedores', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT pp.id,
              pp.producto_id,
              pp.proveedor_id,
              DATE_FORMAT(pp.fecha_ultima_compra, '%Y-%m-%d') AS fecha_ultima_compra,
              pp.documento,
              pp.cantidad,
              prov.nombre_empresa
         FROM producto_proveedores pp
         INNER JOIN proveedores prov ON prov.id = pp.proveedor_id
        ORDER BY pp.producto_id ASC,
                 pp.fecha_ultima_compra DESC,
                 pp.id DESC`
    )
    res.json(rows)
  } catch (error) {
    console.error('Error al obtener producto-proveedores:', error)
    res.status(500).json({ error: 'Error al obtener las relaciones producto-proveedor.' })
  }
})

// ─────────────────────────────────────────────────────────────────────────────
// CREAR PRODUCTO (CON IMÁGENES A CLOUDINARY)
// ─────────────────────────────────────────────────────────────────────────────
app.post('/api/inventario', autenticar, autorizar('p_inventario'), uploadMem.array('imagenes', 2), async (req, res) => {
    try {
        const { categoria_id, nombre, descripcion, sku, stock_actual, stock_minimo, precio_compra_referencia, precio_venta_sugerido } = req.body;

        // Subir imágenes a Cloudinary si existen
        let imagen1_url = null;
        let imagen2_url = null;

        if (req.files && req.files.length > 0) {
            // Primera imagen
            const b64_1 = Buffer.from(req.files[0].buffer).toString("base64");
            const dataURI_1 = "data:" + req.files[0].mimetype + ";base64," + b64_1;
            const upload1 = await cloudinary.uploader.upload(dataURI_1, {
                folder: 'brinco-erp/productos',
                resource_type: 'image'
            });
            imagen1_url = upload1.secure_url;

            // Segunda imagen (si existe)
            if (req.files[1]) {
                const b64_2 = Buffer.from(req.files[1].buffer).toString("base64");
                const dataURI_2 = "data:" + req.files[1].mimetype + ";base64," + b64_2;
                const upload2 = await cloudinary.uploader.upload(dataURI_2, {
                    folder: 'brinco-erp/productos',
                    resource_type: 'image'
                });
                imagen2_url = upload2.secure_url;
            }
        }

        const sql = "INSERT INTO brinco_creativo.productos (categoria_id, nombre, descripcion, sku, stock_actual, stock_minimo, precio_compra_referencia, precio_venta_sugerido, imagen1_url, imagen2_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        const [result] = await db.query(sql, [categoria_id, nombre, descripcion, sku, stock_actual, stock_minimo, precio_compra_referencia, precio_venta_sugerido, imagen1_url, imagen2_url]);
        
        res.json({ id: result.insertId });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────
// ACTUALIZAR PRODUCTO (CON IMÁGENES A CLOUDINARY)
// ─────────────────────────────────────────────────────────────────────────────
app.put('/api/inventario/:id', autenticar, autorizar('p_inventario'), uploadMem.array('imagenes', 2), async (req, res) => {
    const { id } = req.params;
    const { categoria_id, nombre, descripcion, sku, stock_actual, stock_minimo, precio_compra_referencia, precio_venta_sugerido, eliminar_imagen1, eliminar_imagen2 } = req.body;
    
    try {
        // Obtener URLs actuales de la base de datos
        const [actual] = await db.query("SELECT imagen1_url, imagen2_url FROM brinco_creativo.productos WHERE id = ?", [id]);
        
        if (actual.length === 0) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        let imagen1_url = actual[0].imagen1_url;
        let imagen2_url = actual[0].imagen2_url;

        // Manejar eliminación de imágenes existentes
        if (eliminar_imagen1 === 'true') {
            imagen1_url = null;
        }
        if (eliminar_imagen2 === 'true') {
            imagen2_url = null;
        }

        // Subir nuevas imágenes si se enviaron
        if (req.files && req.files.length > 0) {
            const b64_1 = Buffer.from(req.files[0].buffer).toString("base64");
            const dataURI_1 = "data:" + req.files[0].mimetype + ";base64," + b64_1;
            const upload1 = await cloudinary.uploader.upload(dataURI_1, {
                folder: 'brinco-erp/productos',
                resource_type: 'image'
            });
            imagen1_url = upload1.secure_url;

            if (req.files[1]) {
                const b64_2 = Buffer.from(req.files[1].buffer).toString("base64");
                const dataURI_2 = "data:" + req.files[1].mimetype + ";base64," + b64_2;
                const upload2 = await cloudinary.uploader.upload(dataURI_2, {
                    folder: 'brinco-erp/productos',
                    resource_type: 'image'
                });
                imagen2_url = upload2.secure_url;
            }
        }

        const sql = "UPDATE brinco_creativo.productos SET categoria_id = ?, nombre = ?, descripcion = ?, sku = ?, stock_actual = ?, stock_minimo = ?, precio_compra_referencia = ?, precio_venta_sugerido = ?, imagen1_url = ?, imagen2_url = ? WHERE id = ?";
        await db.query(sql, [categoria_id, nombre, descripcion, sku, stock_actual, stock_minimo, precio_compra_referencia, precio_venta_sugerido, imagen1_url, imagen2_url, id]);
        
        res.json({ id: id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Cambiar solo el estado (activo/desactivo) de un producto
app.patch('/api/inventario/:id/estado', autenticar, autorizar('p_inventario'), async (req, res) => {
    const { id } = req.params;
    const { activo } = req.body;
    try {
        await db.query("UPDATE brinco_creativo.productos SET activo = ? WHERE id = ?", [activo ? 1 : 0, id]);
        res.json({ message: 'Estado actualizado correctamente' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Cambiar solo el estado (activo/desactivo) de un producto
app.patch('/api/inventario/:id/estado',autenticar, autorizar('p_inventario'), async (req, res) => {
    const { id } = req.params;
    const { activo } = req.body;
    try {
        // Convertimos booleano a 0/1
        await db.query("UPDATE productos SET activo = ? WHERE id = ?", [activo ? 1 : 0, id]);
        res.json({ message: 'Estado actualizado correctamente' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/categorias',autenticar, autorizar('p_cat_productos'), async (req, res) => {
    try {
        const sql = `SELECT c.*, (SELECT COUNT(*) FROM productos WHERE categoria_id = c.id) as total_productos FROM categorias c ORDER BY c.nombre ASC`;
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Crear nueva categoría de producto
app.post('/api/categorias', autenticar, autorizar('p_cat_productos'), async (req, res) => {
    const { nombre, descripcion, activo, color_clase, icono } = req.body;
    try {
        const sql = "INSERT INTO categorias (nombre, descripcion, activo, color_clase, icono) VALUES (?, ?, ?, ?, ?)";
        const [result] = await db.query(sql, [nombre, descripcion, activo || 1, color_clase, icono || 'category']);
        res.json({ id: result.insertId, message: 'Categoría creada exitosamente' });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ error: 'Ya existe una categoría con ese nombre.' });
        }
        res.status(500).json({ error: err.message });
    }
});

// Actualizar categoría de producto existente
app.put('/api/categorias/:id', autenticar, autorizar('p_cat_productos'),async (req, res) => {
    const { id } = req.params;
    const { nombre, descripcion, activo, color_clase, icono } = req.body;
    try {
        const sql = "UPDATE categorias SET nombre = ?, descripcion = ?, activo = ?, color_clase = ?, icono = ? WHERE id = ?";
        await db.query(sql, [nombre, descripcion, activo, color_clase, icono, id]);
        res.json({ message: 'Categoría actualizada correctamente' });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ error: 'Ya existe otra categoría con ese nombre.' });
        }
        res.status(500).json({ error: err.message });
    }
});

// Crear nueva categoría de clientes
app.post('/api/clientes/categorias',autenticar, autorizar('p_cat_clientes'), async (req, res) => {
    const { nombre, descripcion, color_clase } = req.body;
    try {
        const sql = "INSERT INTO clientes_categorias (nombre, descripcion, color_clase) VALUES (?, ?, ?)";
        const [result] = await db.query(sql, [nombre, descripcion, color_clase]);
        res.json({ id: result.insertId, message: 'Categoría creada exitosamente' });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ error: 'Ya existe una categoría con ese nombre.' });
        }
        res.status(500).json({ error: err.message });
    }
});

// Actualizar categoría existente
app.put('/api/clientes/categorias/:id',autenticar, autorizar('p_cat_clientes'), async (req, res) => {
    const { id } = req.params;
    const { nombre, descripcion, color_clase } = req.body;
    try {
        const sql = "UPDATE clientes_categorias SET nombre = ?, descripcion = ?, color_clase = ? WHERE id = ?";
        await db.query(sql, [nombre, descripcion, color_clase, id]);
        res.json({ message: 'Categoría actualizada correctamente' });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ error: 'Ya existe otra categoría con ese nombre.' });
        }
        res.status(500).json({ error: err.message });
    }
});

// =============================================================================
// ÓRDENES DE TRABAJO Y PRODUCCIÓN
// =============================================================================

app.get('/api/ordenes',autenticar, autorizar('p_ordenes'), async (req, res) => {
    try {
        const sql = `
            SELECT o.*, c.nombre_completo as cliente_nombre, p.numero_cotizacion as presupuesto_num,
            (SELECT COALESCE(SUM(CASE WHEN tipo_movimiento = 'Ingreso' THEN monto ELSE -monto END), 0) FROM pagos WHERE orden_id = o.id) as total_pagado,
            (SELECT COUNT(*) FROM orden_evidencias WHERE orden_id = o.id) as total_evidencias
            FROM ordenes o 
            JOIN clientes c ON o.cliente_id = c.id 
            LEFT JOIN presupuestos p ON o.presupuesto_id = p.id
            ORDER BY o.fecha_orden DESC`;
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: 'Fallo al cargar tablero: ' + err.message });
    }
});

app.post('/api/ordenes', autenticar, autorizar('p_nueva_orden'), async (req, res) => {
    const { cliente_id, fecha_entrega, subtotal, costo_materiales, mano_obra, envio, cargo_admin, total, utilidad_porcentaje, notas, presupuesto_id } = req.body;
    // Si viene vacío, le asignamos NULL
    const fechaEntregaFinal = fecha_entrega === '' ? null : fecha_entrega;

    // NUEVO: Bloquear si no hay fecha
    if (!fechaEntregaFinal) {
        return res.status(400).json({ error: 'La fecha de entrega prometida es obligatoria.' });
    }
    const conn = await pool.promise().getConnection();
    try {
        await conn.beginTransaction();
        
        // Insertamos la orden SIN materiales, solo vinculada a la cotización
        const sqlO = "INSERT INTO brinco_creativo.ordenes (cliente_id, presupuesto_id, fecha_entrega_prometida, subtotal, total_costo_materiales, costo_mano_obra, costo_envio, cargo_administrativo, total_quetzales, porcentaje_utilidad_aplicado, notas_personalizacion, stock_rebajado) VALUES (?,?,?,?,?,?,?,?,?,?,?,0)";
        const [resO] = await conn.query(sqlO, [cliente_id, presupuesto_id || null, fechaEntregaFinal, subtotal, costo_materiales, mano_obra, envio, cargo_admin, total, utilidad_porcentaje, notas]);

        // Si la orden viene de una cotización, marcamos la cotización como "Convertida"
        if (presupuesto_id) {
            await conn.query("UPDATE brinco_creativo.presupuestos SET estado = 'Convertida' WHERE id = ?", [presupuesto_id]);
        }

        await conn.commit();
        res.json({ id: resO.insertId });
    } catch (err) {
        await conn.rollback();
        res.status(400).json({ error: 'No se pudo crear la orden: ' + err.message });
    } finally {
        conn.release();
    }
});

// ==========================================================
// MANTENIMIENTO DE MATERIALES POR ORDEN
// ==========================================================
app.post('/api/ordenes/:id/rebajar-stock',autenticar, autorizar('p_ordenes'), async (req, res) => {
    const { id } = req.params;
    const conn = await pool.promise().getConnection();
    try {
        await conn.beginTransaction();
        
        // Buscamos los materiales en la cotización vinculada a esta orden
        const [materiales] = await conn.query(`
            SELECT pdm.producto_id, pdm.cantidad 
            FROM brinco_creativo.presupuestos_detalles_materiales pdm
            JOIN brinco_creativo.ordenes o ON o.presupuesto_id = pdm.presupuesto_id
            WHERE o.id = ?
        `, [id]);
        
        for (const m of materiales) {
            await conn.query("UPDATE brinco_creativo.productos SET stock_actual = stock_actual - ? WHERE id = ?", [m.cantidad, m.producto_id]);
        }
        
        await conn.query("UPDATE brinco_creativo.ordenes SET stock_rebajado = 1 WHERE id = ?", [id]);
        await conn.commit();
        res.json({ message: 'Existencias descontadas del inventario' });
    } catch (err) {
        await conn.rollback();
        res.status(400).json({ error: 'Fallo en proceso de stock: ' + err.message });
    } finally {
        conn.release();
    }
});

// Endpoint para devolver stock y cancelar la orden
app.post('/api/ordenes/:id/devolver-stock', autenticar, autorizar('p_ordenes'), async (req, res) => {
    const { id } = req.params;
    const conn = await pool.promise().getConnection();
    try {
        await conn.beginTransaction();
        
        // 1. Buscamos los materiales que se habían descontado
        const [materiales] = await conn.query("SELECT producto_id, cantidad FROM orden_detalles_materiales WHERE orden_id = ?", [id]);
        
        // 2. Sumamos el stock de vuelta a los productos
        for (const m of materiales) {
            await conn.query("UPDATE productos SET stock_actual = stock_actual + ? WHERE id = ?", [m.cantidad, m.producto_id]);
        }
        
        // 3. Marcamos la orden como que ya no tiene stock descontado y la cancelamos
        await conn.query("UPDATE ordenes SET stock_rebajado = 0, estado = 'Cancelado' WHERE id = ?", [id]);
        
        await conn.commit();
        res.json({ message: 'Stock devuelto al inventario y orden cancelada' });
    } catch (err) {
        await conn.rollback();
        res.status(400).json({ error: 'Fallo al devolver stock: ' + err.message });
    } finally {
        conn.release();
    }
});

app.patch('/api/ordenes/:id/estado', autenticar, autorizar('p_ordenes'), async (req, res) => {
    const { id } = req.params;
    const { estado } = req.body;
    try {
        const sql = "UPDATE ordenes SET estado = ? WHERE id = ?";
        await db.query(sql, [estado, id]);
        res.json({ message: 'Estado de orden actualizado' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// =============================================================================
// 7. PROVEEDORES Y ABASTECIMIENTO (MANTENIDO)
// =============================================================================

app.get('/api/proveedores', autenticar, autorizar('p_proveedores'), async (req, res) => {
    try { const [results] = await db.query("SELECT * FROM proveedores ORDER BY nombre_empresa ASC"); res.json(results); } 
    catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/proveedores', autenticar, autorizar('p_proveedores'), async (req, res) => {
    const { nombre_empresa, contacto_nombre, telefono, email, direccion, nit } = req.body;
    try {
        const [result] = await db.query("INSERT INTO proveedores (nombre_empresa, contacto_nombre, telefono, email, direccion, nit) VALUES (?,?,?,?,?,?)", [nombre_empresa, contacto_nombre, telefono, email, direccion, nit]);
        res.json({ id: result.insertId });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/proveedores/:id', autenticar, autorizar('p_proveedores'), async (req, res) => {
    const { nombre_empresa, contacto_nombre, telefono, email, direccion, nit } = req.body;
    try { await db.query("UPDATE proveedores SET nombre_empresa=?, contacto_nombre=?, telefono=?, email=?, direccion=?, nit=? WHERE id=?", [nombre_empresa, contacto_nombre, telefono, email, direccion, nit, req.params.id]); res.json({ message: 'Proveedor actualizado' }); } 
    catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/proveedores/:id/compras', autenticar, autorizar('p_proveedores'), async (req, res) => {
    try { const [results] = await db.query("SELECT * FROM entradas_mercancia WHERE proveedor_id = ? ORDER BY fecha_entrada DESC", [req.params.id]); res.json(results); } 
    catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================================
// 8. ABASTECIMIENTO Y CAJA (MANTENIDO)
// =============================================================================

app.post('/api/entradas', autenticar, autorizar('p_entrada_mercancia'), async (req, res) => {
    const { proveedor_id, documento, total, items } = req.body;
    const conn = await pool.promise().getConnection();
    try {
        await conn.beginTransaction();
        const [resE] = await conn.query("INSERT INTO entradas_mercancia (proveedor_id, documento_referencia, total_compra) VALUES (?,?,?)", [proveedor_id, documento, total]);
        for (const i of items) {
            await conn.query("INSERT INTO entrada_detalles (entrada_id, producto_id, cantidad, costo_unitario) VALUES (?,?,?,?)", [resE.insertId, i.producto_id, i.cantidad, i.costo]);
            await conn.query("UPDATE productos SET stock_actual = stock_actual + ?, precio_compra_referencia = ? WHERE id = ?", [i.cantidad, i.costo, i.producto_id]);
        }
        // NUEVO BRINCO: historial producto <-> proveedor
        // Si nunca se le compró este producto a este proveedor, CREA la fila.
        // Si ya existía, ACTUALIZA fecha, documento y cantidad con ESTA compra.
        if (proveedor_id) {
        for (const item of items) {
            if (item.producto_id) {
            await conn.query(
                `INSERT INTO producto_proveedores
                (producto_id, proveedor_id, fecha_ultima_compra, documento, cantidad)
                VALUES (?, ?, CURDATE(), ?, ?) AS nueva
                ON DUPLICATE KEY UPDATE
                fecha_ultima_compra = nueva.fecha_ultima_compra,
                documento = nueva.documento,
                cantidad = nueva.cantidad`,
                [item.producto_id, proveedor_id, documento, item.cantidad]
            )
            }
        }
        }
        await conn.commit(); res.json({ id: resE.insertId });
    } catch (err) { await conn.rollback(); res.status(500).json({ error: err.message }); }
    finally { conn.release(); }
});

// =============================================================================
// CATÁLOGO DE MÉTODOS DE PAGO
// =============================================================================

app.get(
    '/api/catalogos/metodos-pago',
    autenticar,
    autorizar('p_caja'),
    async (req, res) => {

        try {

            const [rows] = await db.query(`
                SELECT

                    id,
                    nombre,
                    codigo,
                    icono,
                    color,
                    requiere_referencia,
                    permite_vuelto,
                    permite_pago_mixto,
                    activo,
                    orden_visualizacion

                FROM brinco_creativo.catalogo_metodos_pago

                WHERE activo = 1

                ORDER BY orden_visualizacion,
                         nombre
            `);

            res.json(rows);

        } catch (err) {

            console.error(err);

            res.status(500).json({
                error: 'Error al obtener el catálogo de métodos de pago.',
                detalle: err.message
            });

        }

    }
);

// =============================================================================
// CAJA, FLUJO Y PAGOS
// =============================================================================

app.get('/api/pagos', autenticar, autorizar('p_caja'), async (req, res) => {
    try {
        const sql = `
            SELECT 
                p.id, p.orden_id, p.presupuesto_id, p.caja_cierre_id, p.fecha_pago, p.monto, 
                p.tipo_movimiento, p.categoria_pago, p.metodo_pago_id, 
                mp.nombre AS metodo_pago_nombre, mp.codigo AS metodo_pago_codigo,
                p.referencia_pago, p.nota_pago, p.origen_pago, p.descripcion_origen,
                o.id AS orden_num, o.estado AS orden_estado,
                pres.numero_cotizacion AS presupuesto_num,
                c.id AS cliente_id, c.nombre_completo AS cliente_nombre,
                CONCAT('#', pres.numero_cotizacion, ' - ', c.nombre_completo) AS presupuesto_descripcion
            FROM brinco_creativo.pagos p
            LEFT JOIN brinco_creativo.catalogo_metodos_pago mp ON mp.id = p.metodo_pago_id
            LEFT JOIN brinco_creativo.ordenes o ON o.id = p.orden_id
            LEFT JOIN brinco_creativo.presupuestos pres ON pres.id = p.presupuesto_id
            LEFT JOIN brinco_creativo.clientes c ON c.id = COALESCE(o.cliente_id, pres.cliente_id)
            ORDER BY p.fecha_pago DESC, p.id DESC
        `;
        const [results] = await db.query(sql);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/pagos', autenticar, autorizar('p_operar_caja'), async (req, res) => {
    const { orden_id, presupuesto_id, monto, tipo_movimiento, categoria_pago, metodo_pago_id, referencia_pago, nota_pago, origen_pago, descripcion_origen } = req.body;
    const usuario_id = req.usuario.id;

    // =========================================================
    // VALIDACIONES
    // =========================================================
    if (!monto || isNaN(monto) || Number(monto) <= 0) {
        return res.status(400).json({ error: 'Debe ingresar un monto válido mayor que cero.' });
    }
    if (!tipo_movimiento) {
        return res.status(400).json({ error: 'Debe indicar el tipo de movimiento.' });
    }
    if (!metodo_pago_id) {
        return res.status(400).json({ error: 'Debe seleccionar un método de pago.' });
    }

    try {
        // =========================================================
        // BUSCAR CAJA ABIERTA DEL USUARIO
        // =========================================================
        const [caja] = await db.query(`
            SELECT id FROM brinco_creativo.cajas_cierres 
            WHERE usuario_id = ? AND estado = 'Abierta' LIMIT 1
        `, [usuario_id]);

        if (caja.length === 0) {
            return res.status(400).json({ error: 'Debe abrir una caja antes de registrar movimientos.' });
        }
        const caja_id = caja[0].id;

        // =========================================================
        // VALIDAR MÉTODO DE PAGO
        // =========================================================
        const [metodo] = await db.query(`
            SELECT id, nombre, codigo, requiere_referencia, permite_vuelto, permite_pago_mixto, activo 
            FROM brinco_creativo.catalogo_metodos_pago 
            WHERE id = ? LIMIT 1
        `, [metodo_pago_id]);

        if (metodo.length === 0) {
            return res.status(400).json({ error: 'El método de pago seleccionado no existe.' });
        }
        if (Number(metodo[0].activo) !== 1) {
            return res.status(400).json({ error: 'El método de pago está deshabilitado.' });
        }
        if (Number(metodo[0].requiere_referencia) === 1 && (!referencia_pago || referencia_pago.trim() === '')) {
            return res.status(400).json({ error: 'Este método de pago requiere una referencia.' });
        }

        // =========================================================
        // VALIDAR ORIGEN DEL MOVIMIENTO
        // =========================================================
        const origenFinal = origen_pago || 'GENERAL';
        const descripcionFinal = descripcion_origen && descripcion_origen.trim() !== '' ? descripcion_origen.trim() : null;

        if (origenFinal === 'ORDEN') {
            // Si es de origen ORDEN, debe venir al menos un orden_id o presupuesto_id
            if (!orden_id && !presupuesto_id) {
                return res.status(400).json({ error: 'Debe seleccionar una orden o cotización.' });
            }

            // Si viene orden_id, validamos que exista en DB.
            if (orden_id) {
                const [orden] = await db.query(`SELECT id FROM brinco_creativo.ordenes WHERE id = ? LIMIT 1`, [orden_id]);
                if (orden.length === 0) {
                    return res.status(400).json({ error: 'La orden indicada no existe.' });
                }
            }
        }

        // =========================================================
        // REGISTRAR MOVIMIENTO
        // =========================================================
        const [result] = await db.query(`
            INSERT INTO brinco_creativo.pagos 
            (orden_id, presupuesto_id, caja_cierre_id, monto, tipo_movimiento, categoria_pago, metodo_pago_id, referencia_pago, nota_pago, origen_pago, descripcion_origen) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            orden_id || null, 
            presupuesto_id || null, 
            caja_id, 
            Number(monto), 
            tipo_movimiento, 
            categoria_pago, 
            metodo_pago_id, 
            referencia_pago || null, 
            nota_pago || null, 
            origenFinal, 
            descripcionFinal
        ]);

        // =========================================================
        // RESPUESTA
        // =========================================================
        res.json({
            ok: true,
            mensaje: 'Movimiento registrado correctamente.',
            id: result.insertId,
            caja_cierre_id: caja_id,
            metodo_pago: {
                id: metodo[0].id,
                nombre: metodo[0].nombre,
                codigo: metodo[0].codigo
            }
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error interno del servidor.', detalle: err.message });
    }
});

app.get('/api/caja/resumen', autenticar, autorizar('p_caja'), async (req, res) => {
    try {
        const sql = "SELECT COALESCE(SUM(CASE WHEN tipo_movimiento='Ingreso' THEN monto ELSE 0 END),0) as ingresos_hoy, COALESCE(SUM(CASE WHEN tipo_movimiento='Egreso' THEN monto ELSE 0 END),0) as egresos_hoy, 500.00 as fondo_inicial FROM pagos WHERE DATE(fecha_pago)=CURDATE()";
        const [results] = await db.query(sql);
        res.json(results[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// =============================================================================
// APERTURA DE CAJA
// =============================================================================

app.get('/api/caja/abierta', autenticar, autorizar('p_caja'), async (req, res) => {
        console.log('req.usuario =', req.usuario);
    try {

        const usuarioId = req.usuario.id;

        const [rows] = await db.query(`
            SELECT
                cc.id,
                cc.usuario_id,
                u.nombre,
                cc.fecha_apertura,
                cc.monto_inicial
            FROM brinco_creativo.cajas_cierres cc
            INNER JOIN brinco_creativo.usuarios u
                ON u.id = cc.usuario_id
            WHERE
                cc.usuario_id = ?
                AND cc.estado='Abierta'
            LIMIT 1
        `, [usuarioId]);

        if (rows.length === 0) {
            return res.json({ abierta: false });
        }

        res.json({
            abierta: true,
            ...rows[0]
        });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/caja/apertura', autenticar, autorizar('p_apertura_caja'), async (req, res) => {

    const { monto_inicial } = req.body;
    const usuarioId = req.usuario.id;

    try {

        if (monto_inicial === undefined || isNaN(monto_inicial) || Number(monto_inicial) < 0) {
            return res.status(400).json({
                ok: false,
                error: 'Debe indicar un monto inicial válido.'
            });
        }

        const [cajaAbierta] = await db.query(`
            SELECT id
            FROM brinco_creativo.cajas_cierres
            WHERE usuario_id = ?
            AND estado = 'Abierta'
            LIMIT 1
        `, [usuarioId]);

        if (cajaAbierta.length > 0) {
            return res.status(409).json({
                ok: false,
                error: 'Ya existe una caja abierta para este usuario.'
            });
        }

        const [resultado] = await db.query(`
            INSERT INTO brinco_creativo.cajas_cierres
            (
                usuario_id,
                fecha_apertura,
                monto_inicial,
                estado
            )
            VALUES
            (
                ?,
                NOW(),
                ?,
                'Abierta'
            )
        `, [
            usuarioId,
            Number(monto_inicial)
        ]);

        res.json({
            ok: true,
            mensaje: 'Caja abierta correctamente.',
            caja_id: resultado.insertId
        });

    } catch (error) {

        console.error(error);

        res.status(500).json({
            ok: false,
            error: error.message
        });

    }

});


// =============================================================================
// CIERRE DE CAJA
// =============================================================================

app.post('/api/caja/cierre', autenticar, autorizar('p_cierre_caja'), async (req, res) => {

    const usuarioId = req.usuario.id;
    const { monto_real, observaciones } = req.body;

    try {

        const [cajas] = await db.query(`
            SELECT *
            FROM brinco_creativo.cajas_cierres
            WHERE usuario_id = ?
            AND estado = 'Abierta'
            LIMIT 1
        `, [usuarioId]);

        if (cajas.length === 0) {
            return res.status(404).json({
                ok: false,
                error: 'No existe una caja abierta para este usuario.'
            });
        }

        const caja = cajas[0];

        const [movimientos] = await db.query(`
            SELECT

                COALESCE(SUM(
                    CASE
                        WHEN tipo_movimiento='Ingreso'
                        THEN monto
                        ELSE 0
                    END
                ),0) ingresos,

                COALESCE(SUM(
                    CASE
                        WHEN tipo_movimiento='Egreso'
                        THEN monto
                        ELSE 0
                    END
                ),0) egresos

            FROM brinco_creativo.pagos

            WHERE caja_cierre_id = ?

        `, [caja.id]);

        const ingresos = Number(movimientos[0].ingresos);
        const egresos = Number(movimientos[0].egresos);

        const esperado =
            Number(caja.monto_inicial) +
            ingresos -
            egresos;

        const diferencia =
            Number(monto_real) -
            esperado;

        await db.query(`
            UPDATE brinco_creativo.cajas_cierres
            SET

                fecha_cierre = NOW(),

                monto_final_esperado = ?,

                monto_final_real = ?,

                diferencia = ?,

                observaciones = ?,

                estado = 'Cerrada'

            WHERE id = ?
        `, [

            esperado,
            Number(monto_real),
            diferencia,
            observaciones,
            caja.id

        ]);

        res.json({

            ok: true,

            mensaje: 'Caja cerrada correctamente.',

            esperado,

            diferencia

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            ok: false,

            error: error.message

        });

    }

});


// =============================================================================
// HISTORICO DE CAJAS
// =============================================================================

app.get('/api/caja/historico', autenticar, autorizar('p_historial_caja'), async (req, res) => {

    try {

        const [rows] = await db.query(`

            SELECT

                cc.id,

                cc.usuario_id,

                u.nombre AS usuario,

                cc.fecha_apertura,

                cc.fecha_cierre,

                cc.monto_inicial,

                cc.monto_final_esperado,

                cc.monto_final_real,

                cc.diferencia,

                cc.estado,

                cc.observaciones

            FROM brinco_creativo.cajas_cierres cc

            INNER JOIN brinco_creativo.usuarios u

                ON u.id = cc.usuario_id

            ORDER BY cc.id DESC

        `);

        res.json({

            ok: true,

            data: rows

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            ok: false,

            error: error.message

        });

    }

});

// =============================================================================
// REPORTE DE CAJA (FILTRABLE)
// =============================================================================
app.get('/api/caja/reporte', autenticar, autorizar('p_caja'), async (req, res) => {
    try {
        const { fechaInicio, fechaFin, usuarioId, cajaId, ordenId, numeroCotizacion } = req.query;
        
        let sql = `
            SELECT 
                p.id, p.fecha_pago, p.monto, p.tipo_movimiento, p.categoria_pago, 
                p.referencia_pago, p.nota_pago, p.origen_pago, p.descripcion_origen,
                mp.nombre AS metodo_pago,
                cc.id AS caja_id, u.nombre AS usuario_nombre,
                o.id AS orden_id, c.nombre_completo AS cliente_nombre,
                pres.numero_cotizacion AS presupuesto_num
            FROM brinco_creativo.pagos p
            LEFT JOIN cajas_cierres cc ON p.caja_cierre_id = cc.id
            LEFT JOIN usuarios u ON cc.usuario_id = u.id
            LEFT JOIN catalogo_metodos_pago mp ON p.metodo_pago_id = mp.id
            LEFT JOIN ordenes o ON p.orden_id = o.id
            LEFT JOIN presupuestos pres ON p.presupuesto_id = pres.id
            LEFT JOIN clientes c ON c.id = COALESCE(o.cliente_id, pres.cliente_id)
            WHERE 1=1
        `;
        
        const params = [];
        
        if (fechaInicio && fechaFin) {
            sql += ` AND DATE(p.fecha_pago) BETWEEN ? AND ?`;
            params.push(fechaInicio, fechaFin);
        }
        if (usuarioId) {
            sql += ` AND cc.usuario_id = ?`;
            params.push(usuarioId);
        }
        if (cajaId) {
            sql += ` AND p.caja_cierre_id = ?`;
            params.push(cajaId);
        }
        if (ordenId) {
            sql += ` AND p.orden_id = ?`;
            params.push(ordenId);
        }
        if (numeroCotizacion) {
            sql += ` AND pres.numero_cotizacion LIKE ?`;
            params.push(`%${numeroCotizacion}%`);
        }
        
        sql += ` ORDER BY p.fecha_pago DESC`;
        
        const [results] = await db.query(sql, params);
        res.json(results);
    } catch (err) {
        res.status(500).json({ error: 'Error al generar reporte: ' + err.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────
// Carga todas las fotos de una orden con sus tags ya asignados
// ─────────────────────────────────────────────────────────────────────────────
app.get('/api/ordenes/:id/evidencias',autenticar, autorizar('p_ordenes'),async (req, res) => {
    try {
        // Fotos de la orden
        const [fotos] = await db.query(
            `SELECT id, url_archivo, created_at 
             FROM orden_evidencias 
             WHERE orden_id = ? 
             ORDER BY created_at ASC`,
            [req.params.id]
        );

        // Para cada foto, obtener sus tags
        const fotosConTags = await Promise.all(
            fotos.map(async (foto) => {
                const [tags] = await db.query(
                    `SELECT t.id as tag_id, t.slug, t.nombre,
                            c.id as categoria_id, c.slug as categoria_slug,
                            c.nombre as categoria_nombre, c.color_clase, c.icono
                     FROM evidencia_tags et
                     JOIN cat_tags t ON et.tag_id = t.id
                     JOIN cat_tag_categorias c ON t.categoria_id = c.id
                     WHERE et.evidencia_id = ?
                     ORDER BY c.orden, t.orden`,
                    [foto.id]
                );
                return { ...foto, tags };
            })
        );

        res.json(fotosConTags);
    } catch (err) {
        res.status(500).json({ error: 'Error al cargar evidencias: ' + err.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────
// Sube una o varias fotos nuevas a una orden
// ─────────────────────────────────────────────────────────────────────────────
app.post('/api/ordenes/:id/evidencias', autenticar, autorizar('p_ordenes'), uploadMem.array('fotos', 10), async (req, res) => {
    const { id } = req.params;
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ error: 'No se recibieron archivos' });
        }

        const nuevasFotos = [];
        for (const file of req.files) {
            const b64 = Buffer.from(file.buffer).toString("base64");
            const dataURI = "data:" + file.mimetype + ";base64," + b64;
            
            // Detectar si es imagen o video
            const resource_type = file.mimetype.startsWith('video/') ? 'video' : 'image';
            
            const uploadResponse = await cloudinary.uploader.upload(dataURI, {
                folder: 'brinco-erp/evidencias',
                resource_type: resource_type
            });
            
            const [result] = await db.query(
                'INSERT INTO orden_evidencias (orden_id, url_archivo) VALUES (?, ?)',
                [id, uploadResponse.secure_url]
            );
            
            nuevasFotos.push({
                id: result.insertId,
                url_archivo: uploadResponse.secure_url,
                tags: []
            });
        }

        res.json({ message: 'Fotos subidas', fotos: nuevasFotos });
    } catch (err) {
        res.status(500).json({ error: 'Error al subir fotos: ' + err.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────
// Elimina una foto y sus tags en cascada (ON DELETE CASCADE en DB)
// ─────────────────────────────────────────────────────────────────────────────
app.delete('/api/evidencias/:id', autenticar, autorizar('p_ordenes'),async (req, res) => {
    try {
        const { id } = req.params;

        // Obtener la URL para borrar el archivo físico
        const [rows] = await db.query(
            'SELECT url_archivo FROM orden_evidencias WHERE id = ?', [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Evidencia no encontrada' });
        }

        // Borrar archivo físico del disco
        const filePath = '.' + rows[0].url_archivo; // ./uploads/evidencia-xxx.png
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }

        // Borrar de DB (los tags se borran en cascada automáticamente)
        await db.query('DELETE FROM orden_evidencias WHERE id = ?', [id]);

        res.json({ message: 'Evidencia eliminada' });
    } catch (err) {
        res.status(500).json({ error: 'Error al eliminar: ' + err.message });
    }
});

// ─────────────────────────────────────────────────────────────────────────────
// Reemplaza todos los tags de una foto (toggle completo)
// ─────────────────────────────────────────────────────────────────────────────
app.put('/api/evidencias/:id/tags', autenticar, autorizar('p_ordenes'), async (req, res) => {
    const { id } = req.params;
    const { tag_ids } = req.body; // array de IDs

    const conn = await pool.promise().getConnection();
    try {
        await conn.beginTransaction();

        // Borrar todos los tags actuales de esta foto
        await conn.query('DELETE FROM evidencia_tags WHERE evidencia_id = ?', [id]);

        // Insertar los nuevos (si hay alguno)
        if (tag_ids && tag_ids.length > 0) {
            const values = tag_ids.map(tagId => [id, tagId]);
            await conn.query(
                'INSERT INTO evidencia_tags (evidencia_id, tag_id) VALUES ?',
                [values]
            );
        }

        await conn.commit();
        res.json({ message: 'Tags actualizados', total: tag_ids?.length || 0 });
    } catch (err) {
        await conn.rollback();
        res.status(500).json({ error: 'Error al guardar tags: ' + err.message });
    } finally {
        conn.release();
    }
});

// ─────────────────────────────────────────────────────────────────────────────
// Devuelve todos los tags agrupados por categoría para el panel de selección
// ─────────────────────────────────────────────────────────────────────────────
app.get('/api/catalogo/tags', autenticar, async (req, res) => {
    try {
        const [categorias] = await db.query(
            `SELECT id, slug, nombre, icono, color_clase, orden
             FROM cat_tag_categorias
             ORDER BY orden ASC`
        );

        const [tags] = await db.query(
            `SELECT id, categoria_id, slug, nombre, orden
             FROM cat_tags
             WHERE activo = 1
             ORDER BY orden ASC`
        );

        // Agrupar tags dentro de su categoría
        const resultado = categorias.map(cat => ({
            ...cat,
            tags: tags.filter(t => t.categoria_id === cat.id)
        }));

        res.json(resultado);
    } catch (err) {
        res.status(500).json({ error: 'Error al cargar tags: ' + err.message });
    }
});

// =============================================================================
// NUEVO FLUJO DE COTIZACIONES
// =============================================================================

// Listar todas las cotizaciones con su estado y saldo
app.get('/api/presupuestos', autenticar, async (req, res) => {
    try {
        const [rows] = await db.query(`
            SELECT p.id, p.cliente_id, p.numero_cotizacion, p.fecha_creacion, p.total, p.estado, 
                   c.nombre_completo as cliente_nombre, m.simbolo as moneda_simbolo,
                   (SELECT COALESCE(SUM(CASE WHEN tipo_movimiento = 'Ingreso' THEN monto ELSE -monto END), 0) 
                    FROM brinco_creativo.pagos WHERE presupuesto_id = p.id) as total_pagado
            FROM brinco_creativo.presupuestos p
            JOIN brinco_creativo.clientes c ON p.cliente_id = c.id
            JOIN brinco_creativo.monedas m ON p.moneda_id = m.id
            ORDER BY p.fecha_creacion DESC
        `);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// Obtener cotización completa por ID (para cargarla en Nueva Orden o Editarla)
app.get('/api/presupuestos/:id/full', autenticar, async (req, res) => {
    try {
        const [pres] = await db.query(`
            SELECT p.id, p.numero_cotizacion, p.cliente_id, p.total, p.costo_envio, p.descuento, p.texto_adicional, 
                   p.tema_id, p.moneda_id, p.aplica_ipsp, p.valor_ipsp, c.nombre_completo as cliente_nombre
            FROM brinco_creativo.presupuestos p
            JOIN brinco_creativo.clientes c ON p.cliente_id = c.id
            WHERE p.id = ?
        `, [req.params.id]);

        if (pres.length === 0) return res.status(404).json({ error: 'Cotización no encontrada' });

        const [detalles] = await db.query("SELECT id, descripcion, cantidad, precio_unitario, total_linea, color, medidas FROM brinco_creativo.presupuestos_detalles WHERE presupuesto_id = ?", [req.params.id]);
        const [materiales] = await db.query("SELECT producto_id, cantidad, costo_unitario, precio_venta FROM brinco_creativo.presupuestos_detalles_materiales WHERE presupuesto_id = ?", [req.params.id]);
        
        // NUEVO: Traer las imágenes
        const [imagenes] = await db.query("SELECT detalle_id, ruta_archivo, es_grande FROM brinco_creativo.presupuestos_imagenes WHERE presupuesto_id = ?", [req.params.id]);
        
        const imagenesPorLinea = {};
        const imagenesSueltas = [];
        imagenes.forEach(img => {
            const imgObj = { url: img.ruta_archivo, grande: img.es_grande == 1 };
            if (img.detalle_id) {
                if (!imagenesPorLinea[img.detalle_id]) imagenesPorLinea[img.detalle_id] = [];
                imagenesPorLinea[img.detalle_id].push(imgObj);
            } else {
                imagenesSueltas.push(imgObj);
            }
        });

        // Adjuntar las imágenes a su línea correspondiente
        const detallesConImagenes = detalles.map(d => ({
            ...d,
            imagenes: imagenesPorLinea[d.id] || []
        }));
        
        res.json({ 
            ...pres[0], 
            detalles: detallesConImagenes, 
            materiales, 
            imagenes_sueltas: imagenesSueltas 
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Cambiar estado de una cotización (Aceptada, Rechazada, etc.)
app.patch('/api/presupuestos/:id/estado', autenticar, async (req, res) => {
    try {
        await db.query("UPDATE brinco_creativo.presupuestos SET estado = ? WHERE id = ?", [req.body.estado, req.params.id]);
        res.json({ message: 'Estado de cotización actualizado' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// =============================================================================
// ENDPOINTS DE PRESUPUESTOS
// =============================================================================

// Obtener datos iniciales (Temas, Monedas y Envío de la Orden)
app.get('/api/presupuestos/data-inicial', autenticar, async (req, res) => {
    try {
        const [temas] = await db.query("SELECT * FROM temas_presupuesto");
        const [monedas] = await db.query("SELECT * FROM monedas");
        
        // NUEVO: Buscar el costo de envío de la orden original si se proporciona el ID
        let envioOrden = 0;
        if (req.query.orden_id) {
            const [ordenData] = await db.query("SELECT costo_envio FROM ordenes WHERE id = ?", [req.query.orden_id]);
            if (ordenData.length > 0) {
                envioOrden = ordenData[0].costo_envio || 0;
            }
        }

        res.json({ temas, monedas, envio_orden: envioOrden });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Endpoint para subir imágenes (por línea o sueltas)
// Subir imagen de referencia para presupuestos (AHORA A CLOUDINARY)
app.post('/api/presupuestos/upload-img', autenticar, uploadMem.single('imagen'), async (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ error: 'No se subió la imagen' });
        
        // Convertir el archivo de memoria a Base64
        const b64 = Buffer.from(req.file.buffer).toString("base64");
        const dataURI = "data:" + req.file.mimetype + ";base64," + b64;
        
        // Subir a Cloudinary
        const uploadResponse = await cloudinary.uploader.upload(dataURI, {
            folder: 'brinco-erp/presupuestos',
            resource_type: 'image'
        });
        
        res.json({ url: uploadResponse.secure_url });
    } catch (err) {
        console.error('Error al subir imagen de presupuesto:', err.message);
        res.status(500).json({ error: 'Error al subir imagen' });
    }
});

// Crear Presupuesto
// Crear Presupuesto (AHORA CON MATERIALES E IPSP)
app.post('/api/presupuestos', autenticar, async (req, res) => {
    const { cliente_id, orden_id, plantilla_id, moneda_id, lineas, imagenes_sueltas, subtotal, descuento, costo_envio, total, nota_anticipo, texto_adicional, materiales, aplica_ipsp, valor_ipsp } = req.body;
    const conn = await pool.promise().getConnection();
    
    try {
        await conn.beginTransaction();
        
        const now = new Date();
        const dd = String(now.getDate()).padStart(2, '0');
        const mm = String(now.getMonth() + 1).padStart(2, '0');
        const yy = String(now.getFullYear()).slice(-2);
        const prefix = `BC${dd}${mm}${yy}`;
        
        const [lastPres] = await conn.query("SELECT numero_cotizacion FROM brinco_creativo.presupuestos WHERE numero_cotizacion LIKE ? ORDER BY id DESC LIMIT 1", [`${prefix}%`]);
        let consecutivo = 1;
        if (lastPres.length > 0) consecutivo = parseInt(lastPres[0].numero_cotizacion.slice(-2)) + 1;
        const numeroCotizacion = `${prefix}${String(consecutivo).padStart(2, '0')}`;

        const [resP] = await conn.query(
            `INSERT INTO brinco_creativo.presupuestos (numero_cotizacion, cliente_id, orden_id, usuario_id, tema_id, moneda_id, tipo_estructura, subtotal, descuento, costo_envio, total, nota_anticipo, texto_adicional, aplica_ipsp, valor_ipsp, estado) 
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'Borrador')`,
            [numeroCotizacion, cliente_id, orden_id, req.usuario.id, plantilla_id, moneda_id, 'simple', subtotal, descuento, costo_envio, total, nota_anticipo, texto_adicional, aplica_ipsp ? 1 : 0, valor_ipsp || 0]
        );
        
        const presupuestoId = resP.insertId;

        // Guardar líneas de texto (lo que ve el cliente)
        if (lineas && lineas.length > 0) {
            for (const linea of lineas) {
                const [resL] = await conn.query(
                    "INSERT INTO brinco_creativo.presupuestos_detalles (presupuesto_id, descripcion, metadata, color, medidas, cantidad, precio_unitario, total_linea) VALUES (?,?,?,?,?,?,?,?)",
                    [presupuestoId, linea.descripcion, JSON.stringify(linea.metadata || {}), linea.color || '', linea.medidas || '', linea.cantidad, linea.precio_unitario, linea.total_linea]
                );
                
                if (linea.imagenes && linea.imagenes.length > 0) {
                    for (const img of linea.imagenes) {
                        const imgUrl = typeof img === 'string' ? img : img.url;
                        const esGrande = typeof img === 'string' ? 0 : (img.grande ? 1 : 0);
                        await conn.query(
                            "INSERT INTO brinco_creativo.presupuestos_imagenes (presupuesto_id, detalle_id, ruta_archivo, es_grande) VALUES (?,?,?,?)",
                            [presupuestoId, resL.insertId, imgUrl, esGrande]
                        );
                    }
                }
            }
        }

        // Guardar imágenes sueltas
        if (imagenes_sueltas && imagenes_sueltas.length > 0) {
            for (const img of imagenes_sueltas) {
                const imgUrl = typeof img === 'string' ? img : img.url;
                const esGrande = typeof img === 'string' ? 0 : (img.grande ? 1 : 0);
                await conn.query(
                    "INSERT INTO brinco_creativo.presupuestos_imagenes (presupuesto_id, detalle_id, ruta_archivo, es_grande) VALUES (?,?,?,?)",
                    [presupuestoId, null, imgUrl, esGrande]
                );
            }
        }

        // NUEVO: Guardar los materiales (insumos del inventario)
        if (materiales && materiales.length > 0) {
            for (const m of materiales) {
                await conn.query(
                    "INSERT INTO brinco_creativo.presupuestos_detalles_materiales (presupuesto_id, producto_id, cantidad, costo_unitario, precio_venta) VALUES (?,?,?,?,?)",
                    [presupuestoId, m.producto_id, m.cantidad, m.costo_unitario, m.precio_venta]
                );
            }
        }

        await conn.commit();
        res.json({ id: presupuestoId });
    } catch (err) {
        await conn.rollback();
        console.error('ERROR AL GUARDAR PRESUPUESTO:', err.message);
        res.status(500).json({ error: 'Error al guardar el presupuesto: ' + err.message });
    } finally {
        conn.release();
    }
});

// Actualizar Cotización (PUT)
app.put('/api/presupuestos/:id', autenticar, async (req, res) => {
    const { id } = req.params;
    const { plantilla_id, moneda_id, lineas, imagenes_sueltas, subtotal, descuento, costo_envio, total, nota_anticipo, texto_adicional, materiales, aplica_ipsp, valor_ipsp } = req.body;
    const conn = await pool.promise().getConnection();
    
    try {
        await conn.beginTransaction();
        
        // 1. Actualizamos el registro principal
        await conn.query(
            `UPDATE brinco_creativo.presupuestos SET tema_id = ?, moneda_id = ?, subtotal = ?, descuento = ?, costo_envio = ?, total = ?, nota_anticipo = ?, texto_adicional = ?, aplica_ipsp = ?, valor_ipsp = ? WHERE id = ?`,
            [plantilla_id, moneda_id, subtotal, descuento, costo_envio, total, nota_anticipo, texto_adicional, aplica_ipsp ? 1 : 0, valor_ipsp || 0, id]
        );
        
        // 2. Borramos los detalles, imágenes y materiales viejos
        await conn.query("DELETE FROM brinco_creativo.presupuestos_detalles WHERE presupuesto_id = ?", [id]);
        await conn.query("DELETE FROM brinco_creativo.presupuestos_imagenes WHERE presupuesto_id = ?", [id]);
        await conn.query("DELETE FROM brinco_creativo.presupuestos_detalles_materiales WHERE presupuesto_id = ?", [id]);
        
        // 3. Insertamos los nuevos (igual que en el POST)
        if (lineas && lineas.length > 0) {
            for (const linea of lineas) {
                const [resL] = await conn.query(
                    "INSERT INTO brinco_creativo.presupuestos_detalles (presupuesto_id, descripcion, metadata, color, medidas, cantidad, precio_unitario, total_linea) VALUES (?,?,?,?,?,?,?,?)",
                    [id, linea.descripcion, JSON.stringify(linea.metadata || {}), linea.color || '', linea.medidas || '', linea.cantidad, linea.precio_unitario, linea.total_linea]
                );
                if (linea.imagenes && linea.imagenes.length > 0) {
                    for (const img of linea.imagenes) {
                        const imgUrl = typeof img === 'string' ? img : img.url;
                        const esGrande = typeof img === 'string' ? 0 : (img.grande ? 1 : 0);
                        await conn.query("INSERT INTO brinco_creativo.presupuestos_imagenes (presupuesto_id, detalle_id, ruta_archivo, es_grande) VALUES (?,?,?,?)", [id, resL.insertId, imgUrl, esGrande]);
                    }
                }
            }
        }

        if (imagenes_sueltas && imagenes_sueltas.length > 0) {
            for (const img of imagenes_sueltas) {
                const imgUrl = typeof img === 'string' ? img : img.url;
                const esGrande = typeof img === 'string' ? 0 : (img.grande ? 1 : 0);
                await conn.query("INSERT INTO brinco_creativo.presupuestos_imagenes (presupuesto_id, detalle_id, ruta_archivo, es_grande) VALUES (?,?,?,?)", [id, null, imgUrl, esGrande]);
            }
        }

        if (materiales && materiales.length > 0) {
            for (const m of materiales) {
                await conn.query("INSERT INTO brinco_creativo.presupuestos_detalles_materiales (presupuesto_id, producto_id, cantidad, costo_unitario, precio_venta) VALUES (?,?,?,?,?)", [id, m.producto_id, m.cantidad, m.costo_unitario, m.precio_venta]);
            }
        }

        await conn.commit();
        res.json({ id: parseInt(id) });
    } catch (err) {
        await conn.rollback();
        res.status(500).json({ error: 'Error al actualizar: ' + err.message });
    } finally {
        conn.release();
    }
});

// Obtener historial de presupuestos de un cliente
app.get('/api/presupuestos/historial/:clienteId', autenticar, async (req, res) => {
    try {
        const { clienteId } = req.params;
        const [rows] = await db.query(`
            SELECT p.id, p.numero_cotizacion, p.fecha_creacion, p.total, 
                   SUBSTRING(o.notas_personalizacion, 1, 30) as nota_corta,
                   m.simbolo as moneda_simbolo
            FROM presupuestos p
            LEFT JOIN ordenes o ON p.orden_id = o.id
            JOIN monedas m ON p.moneda_id = m.id
            WHERE p.cliente_id = ?
            ORDER BY p.fecha_creacion DESC
        `, [clienteId]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Actualizar fecha de un presupuesto a hoy
app.put('/api/presupuestos/:id/fecha', autenticar, async (req, res) => {
    try {
        await db.query("UPDATE presupuestos SET fecha_creacion = NOW() WHERE id = ?", [req.params.id]);
        res.json({ message: 'Fecha actualizada a hoy' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 5. Generar PDF (Puppeteer)
app.get('/api/presupuestos/:id/pdf', autenticar, async (req, res) => {
    try {
        const { id } = req.params;
        
        const [presRows] = await db.query(`
            SELECT p.*, c.nombre_completo, c.email, c.telefono, c.direccion_envio, 
                   t.color_primario, t.color_secundario, t.color_acento, 
                   m.simbolo as moneda_simbolo
            FROM presupuestos p
            JOIN clientes c ON p.cliente_id = c.id
            JOIN temas_presupuesto t ON p.tema_id = t.id
            JOIN monedas m ON p.moneda_id = m.id
            WHERE p.id = ?`, [id]);
        
        if (presRows.length === 0) return res.status(404).json({ error: 'No encontrado' });
        const pres = presRows[0];
        
        const [detalles] = await db.query("SELECT * FROM presupuestos_detalles WHERE presupuesto_id = ? ORDER BY orden_visual", [id]);
        const [imagenes] = await db.query("SELECT * FROM presupuestos_imagenes WHERE presupuesto_id = ?", [id]);
        
        const getImageBase64 = async (rutaRelativa) => {
            try {
                if (!rutaRelativa) return '';
                
                if (rutaRelativa.startsWith('http')) {
                    const optimizedUrl = rutaRelativa.replace('/upload/', '/upload/w_400,q_auto,f_jpg/');
                    const response = await fetch(optimizedUrl);
                    if (!response.ok) return '';
                    const buffer = Buffer.from(await response.arrayBuffer());
                    return `data:image/jpeg;base64,${buffer.toString('base64')}`;
                }
                
                const absolutePath = path.join(process.cwd(), rutaRelativa);
                if (fs.existsSync(absolutePath)) {
                    const buffer = fs.readFileSync(absolutePath);
                    const ext = path.extname(rutaRelativa).substring(1).toLowerCase() || 'jpeg';
                    return `data:image/${ext};base64,${buffer.toString('base64')}`;
                }
                return '';
            } catch (e) { 
                console.error('Error procesando imagen para PDF:', e.message);
                return ''; 
            }
        };

        const imagenesPorLinea = {};
        const imagenesSueltas = [];
        
        for (const img of imagenes) {
            const base64Url = await getImageBase64(img.ruta_archivo);
            if (!base64Url) continue;
            
            if (img.detalle_id) {
                if (!imagenesPorLinea[img.detalle_id]) imagenesPorLinea[img.detalle_id] = [];
                imagenesPorLinea[img.detalle_id].push({ url: base64Url, grande: img.es_grande === 1 });
            } else {
                imagenesSueltas.push({ url: base64Url, grande: img.es_grande === 1 });
            }
        }

        const generateImageTags = (imgs) => {
            if (!imgs || imgs.length === 0) return '';
            return `<div class="img-container">${imgs.map(img => {
                const imgUrl = typeof img === 'string' ? img : img.url;
                const esGrande = typeof img === 'string' ? false : img.grande;
                if (!imgUrl) return '';
                // Si es grande, ocupa todo. Si no, que ocupe 1/3 del ancho.
                const clase = esGrande ? 'img-grande' : 'img-chica';
                return `<img src="${imgUrl}" class="${clase}" />`;
            }).join('')}</div>`;
        };

        const tieneColor = detalles.some(d => d.color && d.color.trim() !== '');
        const tieneMedidas = detalles.some(d => d.medidas && d.medidas.trim() !== '');

        const filasTabla = detalles.map(d => {
            const imgs = generateImageTags(imagenesPorLinea[d.id]);
            return `<tr>
                <td>
                    <div class="desc-text" style="font-size: 9px;">${d.descripcion}</div>
                </td>
                ${tieneColor ? `<td style="word-wrap: break-word; font-size: 9px;">${d.color || ''}</td>` : ''}
                ${tieneMedidas ? `<td style="word-wrap: break-word; font-size: 9px;">${d.medidas || ''}</td>` : ''}
                <td style="font-size: 9px;">${d.cantidad || ''}</td>
                <td style="font-size: 9px;">${pres.moneda_simbolo} ${d.precio_unitario || ''}</td>
                <td style="font-size: 9px;">${pres.moneda_simbolo} ${d.total_linea}</td>
            </tr>
            <tr>
                <td colspan="${tieneColor ? (tieneMedidas ? '6' : '5') : (tieneMedidas ? '5' : '4')}">
                    ${imgs}
                </td>
            </tr>`;
        }).join('');

        let filaEnvio = '';
        if (pres.costo_envio > 0) {
            filaEnvio = `
            <tr style="background-color: #f8f9fa; font-size: 9px;">
                <td><div class="desc-text" style="font-weight: bold;">Costo de Envío</div></td>
                ${tieneColor ? '<td></td>' : ''}
                ${tieneMedidas ? '<td></td>' : ''}
                <td>1</td>
                <td>${pres.moneda_simbolo} ${pres.costo_envio}</td>
                <td>${pres.moneda_simbolo} ${pres.costo_envio}</td>
            </tr>`;
        }

        let filaIpsp = '';
        if (pres.aplica_ipsp == 1 && pres.valor_ipsp > 0) {
            filaIpsp = `
            <tr style="background-color: #f8f9fa; font-size: 9px;">
                <td><div class="desc-text" style="font-weight: bold;">Timbre de Prensa (IPSP 0.5%)</div></td>
                ${tieneColor ? '<td></td>' : ''}
                ${tieneMedidas ? '<td></td>' : ''}
                <td>1</td>
                <td>${pres.moneda_simbolo} ${parseFloat(pres.valor_ipsp).toFixed(2)}</td>
                <td>${pres.moneda_simbolo} ${parseFloat(pres.valor_ipsp).toFixed(2)}</td>
            </tr>`;
        }
        const seccionSueltas = imagenesSueltas.length > 0 ? `
            <div class="sueltas-section">
                ${generateImageTags(imagenesSueltas)}
            </div>` : '';

        const textoAdicionalHTML = pres.texto_adicional && pres.texto_adicional.trim() !== '' ? `
            <div style="margin-top: 20px; padding: 15px; background-color: #f8f9fa; border-left: 4px solid ${pres.color_acento}; border-radius: 4px; font-size: 12px; color: #555;">
                ${pres.texto_adicional}
            </div>` : '';

        const match = pres.nota_anticipo.match(/(\d+)%/);
        const porcentaje = match ? match[1] : '100';
        const notaTexto = `El presente proyecto es 100% personalizado por lo que el trabajo se inicia con anticipación.<br>La reserva del ${porcentaje}% no es reembolsable depositado a cuenta banco.`;

        let logoBase64 = '';
        const logoPath = path.join(process.cwd(), 'uploads', 'assets', 'logo.png');
        if (fs.existsSync(logoPath)) {
            const logoBuffer = fs.readFileSync(logoPath);
            logoBase64 = `data:image/png;base64,${logoBuffer.toString('base64')}`;
        }

        let html = `
        <html><head><style>
            body { margin: 0; padding: 0; font-family: Arial, sans-serif; color: #333; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important;}
            .sidebar { 
                        position: fixed; 
                        left: 0; top: 0; bottom: 0; 
                        width: 100px; 
                        background-color: #1a3a5c; 
                        display: flex; 
                        align-items: flex-start; 
                        justify-content: center; 
                        padding-top: 40px; 
                        z-index: -1; 
                        -webkit-print-color-adjust: exact !important; 
                        print-color-adjust: exact !important; /* ESTA LÍNEA FUERZA EL COLOR */
                    }
            .sidebar-logo { max-width: 90px; max-height: 120px; object-fit: contain; }
            .content { margin-left: 100px; padding: 40px; }  
            .header-info { margin-bottom: 30px; border-bottom: 2px solid ${pres.color_secundario}; padding-bottom: 20px; }
            .header-title { font-size: 12px; color: #888; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 5px; }
            .header-data { font-size: 14px; color: #333; margin: 0 0 8px 0; }
            .header-flex { display: flex; justify-content: space-between; }
            .tabla { width: 100%; border-collapse: collapse; margin-top: 20px; table-layout: fixed; }
            .tabla th { background-color: ${pres.color_secundario}; color: white; padding: 10px; text-align: left; font-size: 14px; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important;}
            .tabla td { border-bottom: 1px solid #ddd; padding: 10px; vertical-align: top; word-wrap: break-word; }
            .desc-text { margin-bottom: 4px; }
            .img-container { display: flex; flex-direction: row; gap: 8px; width: 100%; margin-top: 4px; margin-bottom: 8px; }
            .img-container img { object-fit: cover; border-radius: 6px; border: 1px solid #eee; }
            .img-grande { width: 100%; max-width: 300px; height: auto; max-height: 300px; flex: none; }
            .img-chica { width: 90px; height: 90px; flex: none; } 
            .sueltas-section { margin-top: 30px; border-top: 2px solid #eee; padding-top: 20px; }
            .totales { text-align: right; margin-top: 30px; }
            .totales p { margin: 5px 0; }
            .totales { page-break-inside: avoid; break-inside: avoid; }
            .footer { page-break-inside: avoid; break-inside: avoid; }
            .footer-nota, .footer-bancos, .footer-empresa { page-break-inside: avoid; }
            .footer { margin-top: 50px; border-top: 2px solid ${pres.color_primario}; padding-top: 20px; font-size: 10px; color: #555; display: block; text-align: left; }
            .footer-nota { line-height: 1.5; margin-bottom: 15px; text-align: left; }
            .footer-bancos { font-weight: bold; color: #333; margin-bottom: 25px; line-height: 1.4; text-align: left; }
            .footer-empresa { text-align: left; }
            .footer-empresa h4 { margin: 0 0 8px 0; color: ${pres.color_primario}; font-size: 16px; font-weight: 900; }
            .footer-empresa p { margin: 3px 0; display: flex; align-items: center; gap: 6px; justify-content: flex-start; }
        </style></head><body>
            <div class="sidebar">
                ${logoBase64 ? `<img src="${logoBase64}" class="sidebar-logo" alt="Logo" />` : `<div style="color: white; font-weight: 900; font-size: 20px; writing-mode: vertical-lr; transform: rotate(180deg);">BRINCO CREATIVO</div>`}
            </div>
            <div class="content">
                <div class="header-info">
                    <div class="header-flex">
                        <div>
                            <p class="header-title">Cotización No:</p>
                            <p class="header-data" style="font-size: 18px; font-weight: 900; color: ${pres.color_primario};">#${pres.numero_cotizacion}</p>
                        </div>
                        <div style="text-align: right;">
                            <p class="header-title">Fecha:</p>
                            <p class="header-data">${new Date(pres.fecha_creacion).toLocaleDateString('es-GT', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
                        </div>
                    </div>
                    <div style="margin-top: 15px; font-size: 9px; line-height: 1.5;">
                        <p style="margin: 0;">
                            <span style="font-weight: 700; color: #888; text-transform: uppercase; letter-spacing: 0.5px;">Cliente:</span> 
                            <span style="font-weight: bold; color: #333;">${pres.nombre_completo}</span>
                        </p>
                        <p style="margin: 0;">
                            <span style="font-weight: 700; color: #888; text-transform: uppercase; letter-spacing: 0.5px;">Contacto:</span> 
                            <span style="color: #333;">${pres.telefono || 'N/A'} | ${pres.email || 'N/A'}</span>
                        </p>
                        <p style="margin: 0;">
                            <span style="font-weight: 700; color: #888; text-transform: uppercase; letter-spacing: 0.5px;">Dirección de Envío:</span> 
                            <span style="color: #333;">${pres.direccion_envio || 'No especificada'}</span>
                        </p>
                    </div>
                </div>
                
                <table class="tabla">
                    <tr>
                        <th style="width: ${tieneColor || tieneMedidas ? '35%' : '50%'};">Descripción</th>
                        ${tieneColor ? '<th style="width: 10%;">Color</th>' : ''}
                        ${tieneMedidas ? '<th style="width: 15%;">Medidas</th>' : ''}
                        <th style="width: 10%;">Cant.</th>
                        <th style="width: 15%;">Precio</th>
                        <th style="width: 15%;">Total</th>
                    </tr>
                    ${filasTabla}
                    ${filaEnvio}
                    ${filaIpsp}
                </table>
                
                ${seccionSueltas}
                ${textoAdicionalHTML}
                
                         <div style="page-break-inside: avoid; padding-top: 40px; padding-bottom: 10px;">
                    <div class="totales" style="font-size: 10px;">
                        <p>Subtotal: ${pres.moneda_simbolo} ${parseFloat(pres.subtotal).toFixed(2)}</p>
                        ${parseFloat(pres.costo_envio) > 0 ? `<p>Envío: ${pres.moneda_simbolo} ${parseFloat(pres.costo_envio).toFixed(2)}</p>` : ''}
                        ${parseFloat(pres.descuento) > 0 ? `<p>Descuento: - ${pres.moneda_simbolo} ${parseFloat(pres.descuento).toFixed(2)}</p>` : ''}
                        ${pres.aplica_ipsp == 1 ? `<p>Timbre de Prensa (IPSP 0.5%): + ${pres.moneda_simbolo} ${parseFloat(pres.valor_ipsp).toFixed(2)}</p>` : ''}
                        <h3 style="color: ${pres.color_primario}; font-size: 12px;">Total: ${pres.moneda_simbolo} ${parseFloat(pres.total).toFixed(2)}</h3>
                    </div>
                </div>

                <div style="display: flex; justify-content: space-between; margin-top: 50px; border-top: 2px solid ${pres.color_primario}; padding-top: 20px; font-size: 10px; color: #555;">
                    <div style="text-align: left; width: 48%;">
                        <h4 style="margin: 0 0 8px 0; color: ${pres.color_primario}; font-size: 14px; font-weight: 900;">Brinco Creativo</h4>
                        <p style="margin: 3px 0;">Ciudad Capital</p>
                        <p style="margin: 3px 0;">brincocreativo.info@gmail.com</p>
                        <p style="margin: 3px 0;">56359748</p>
                    </div>
                    <div style="text-align: right; width: 48%; font-weight: bold; color: #333;">
                        <p style="margin: 0 0 8px 0; font-weight: 900;">Datos Bancarios</p>
                        <p style="margin: 3px 0;">BAC Cuenta: 0000-0000-0000-0000</p>
                        <p style="margin: 3px 0;">Banrural Cuenta: 04913600769182</p>
                        <p style="margin: 3px 0;">A nombre de: Vivian Roxana Villatoro Rodríguez</p>
                    </div>
                </div>
                     
            </body></html>`;

        let browser;
        try {
            browser = await puppeteer.launch({ 
                args: [
                    '--no-sandbox', 
                    '--disable-setuid-sandbox', 
                    '--disable-dev-shm-usage',
                    '--single-process'
                ] 
            });
            
            const page = await browser.newPage();
            await page.setContent(html, { waitUntil: 'networkidle0' });
            
            const pdfBuffer = await page.pdf({ 
                format: 'Letter', 
                printBackground: true, 
                displayHeaderFooter: true,
                headerTemplate: '<div></div>',
                footerTemplate: `
                    <div style="width: 100%; font-size: 9px; color: #888; padding: 0 40px 0 140px; box-sizing: border-box; text-align: right;">
                        pág <span class="pageNumber"></span> de <span class="totalPages"></span>
                    </div>
                `,
                margin: { top: '0px', bottom: '30px', left: '0px', right: '0px' }
            });
            
            /* res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', `inline; filename=Cotizacion-${pres.numero_cotizacion}.pdf`);
            res.send(pdfBuffer); */
        // En lugar de usar Puppeteer, mandamos el HTML al frontend
        res.setHeader('Content-Type', 'text/html');
        res.send(html);

        } catch (pdfErr) {
            console.error('ERROR GENERANDO PDF:', pdfErr);
            res.status(500).json({ error: 'Error generando PDF: ' + pdfErr.message });
        } finally {
            if (browser) {
                await browser.close();
                console.log('✅ Navegador Chrome cerrado correctamente. Memoria liberada.');
            }
        }

    } catch (err) {
        console.error('ERROR GENERAL EN PDF:', err);
        res.status(500).json({ error: 'Error general generando PDF: ' + err.message });
    }
});




// Función de espera (para reintentar cuando Google nos bloquee por 1 minuto)
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// =============================================================================
// Endpoint REAL con Inteligencia Artificial (GROQ - Llama 3)
// =============================================================================
app.post('/api/presupuestos/ia-descripcion', autenticar, async (req, res) => {
    const { palabraClave } = req.body;
    const palabraLimpia = palabraClave ? palabraClave.replace(/\n/g, ' ').trim() : '';

    console.log(`\n--- [CONSULTA IA GROQ] ---`);
    console.log(`1. Palabra clave recibida: "${palabraLimpia}"`);

    if (!palabraLimpia) {
        return res.status(400).json({ error: 'La palabra clave es requerida' });
    }

    try {
        // Configuramos Groq
        const groq = new OpenAI({
            apiKey: process.env.GROQ_API_KEY,
            baseURL: "https://api.groq.com/openai/v1"
        });

        // Hacemos el prompt más estricto para que no salude ni dé opciones
        const prompt = `Eres un redactor técnico comercial para la empresa "Brinco Creativo".
        Tu tarea es redactar una descripción breve, formal y precisa (máximo 2 frases) para un presupuesto, basándote en el siguiente requerimiento: "${palabraLimpia}".
        
        Reglas de Redacción:
        1. Respeto absoluto: Basa la descripción en lo que el usuario solicitó. NO inventes materiales ni técnicas que no se mencionen o que sean técnicamente inviables para el producto (ej: no uses "láser" si es una taza, no uses "metalium" si es un textil).
        2. Menciona el producto, el material (si se indicó) y la técnica (si se indicó).
        3. Redacta en formato de acción/servicio. Ej: "Diseño y sublimación full color sobre...", "Impresión UV en...", "Corte y grabado láser de...". No uses "Diseñamos", usa "Diseño".
        
        Estilo de Brinco Creativo (Sobrio, directo, técnico):
        - "Taza blanca de 11oz con sublimación full color."
        - "Gafete identificador con domo de resina de 5.9 x 2 cm."
        - "Reconocimiento MDF/Acrílico con impresión UV y doble capa."
        
        Reglas estrictas:
        - Tono formal y descriptivo. No uses lenguaje de ventas.
        - El cliente ya solicitó el servicio, solo describe lo que se va a hacer.
        - No saludes, no ofrezcas opciones, no uses comillas (ni simples ni dobles).
        - Responde ÚNICAMENTE con el texto de la descripción.`;

        console.log(`2. Enviando petición a Groq (llama-3.3-70b-versatile,)...`);
        
        const completion = await groq.chat.completions.create({
            model: "llama-3.3-70b-versatile",
            messages: [{ role: "user", content: prompt }],
            temperature: 0.9,
            max_tokens: 150, // Aumentamos el límite para que no se corte la frase
        });

        const descripcionGenerada = completion.choices[0].message.content.trim();
        
        console.log(`✅ 3. RESPUESTA EXITOSA: ${descripcionGenerada}`);
        console.log(`--- [FIN CONSULTA IA] ---\n`);
        
        res.json({ descripcion: descripcionGenerada });
    } catch (err) {
        console.error(`❌ 3. ERROR AL CONSULTAR GROQ:`, err.message);
        
        let mensajeErrorFrontend = 'Error desconocido al conectar con la IA.';
        if (err.message.includes('429')) mensajeErrorFrontend = 'Límite de Groq agotado.';
        if (err.message.includes('401')) mensajeErrorFrontend = 'API Key de Groq inválida.';

        res.status(500).json({ 
            error: mensajeErrorFrontend,
            descripcion: `Diseño personalizado de ${palabraLimpia}, fabricado con materiales premium para destacar tu marca.` 
        });
    }
});

// ==========================================================
// ENDPOINTS ESPECIALES PARA N8N (BOT WHATSAPP)
// ==========================================================

// Buscar cliente por teléfono (para identificar en WhatsApp)
app.get('/api/bot/clientes/telefono/:numero', async (req, res) => {
    try {
        const numero = req.params.numero;
        // Quitamos el prefijo internacional si lo trae (ej. +502) para buscar más flexible
        const numeroLimpio = numero.replace(/\D/g, '').slice(-8); 
        const [rows] = await db.query("SELECT * FROM brinco_creativo.clientes WHERE REPLACE(REPLACE(telefono, ' ', ''), '-', '') LIKE CONCAT('%', ?, '%') LIMIT 1", [numeroLimpio]);
        
        if (rows.length > 0) {
            res.json(rows[0]); // Devuelve el cliente
        } else {
            res.status(404).json({ error: 'No encontrado' });
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Buscar cliente por nombre (AHORA DEVUELVE TODOS LOS DATOS)
app.get('/api/bot/clientes/nombre/:nombre', async (req, res) => {
    try {
        const nombre = req.params.nombre;
        const [rows] = await db.query("SELECT * FROM brinco_creativo.clientes WHERE nombre_completo LIKE CONCAT('%', ?, '%') LIMIT 5", [nombre]);
        res.json(rows); // Devuelve hasta 5 coincidencias con TODA su info
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// =============================================================================
// INICIO DEL SERVIDOR
// =============================================================================

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log('---------------------------------------------------------');
    console.log(`🚀 SERVIDOR MAESTRO v3.7 - ACTIVO EN PUERTO ${PORT}`);
    console.log(`📡 URL API: http://localhost:${PORT}/api`);
    console.log('---------------------------------------------------------');
});